package connectivity;

public class movies 
{
	private String name,actor,actress,director;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}

	public String getActress() {
		return actress;
	}

	public void setActress(String actress) {
		this.actress = actress;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public int getSrNO() {
		return srNO;
	}

	public void setSrNO(int srNO) {
		this.srNO = srNO;
	}

	public int getYearofrelease() {
		return yearofrelease;
	}

	public void setYearofrelease(int yearofrelease) {
		this.yearofrelease = yearofrelease;
	}

	private int srNO,yearofrelease;
	
	

}
